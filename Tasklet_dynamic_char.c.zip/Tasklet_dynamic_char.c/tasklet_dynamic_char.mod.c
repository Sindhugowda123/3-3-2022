#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xe09a23a6, "module_layout" },
	{ 0x600ab2aa, "cdev_del" },
	{ 0x247907d6, "device_destroy" },
	{ 0xdd8932b9, "kthread_stop" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x9f95103f, "class_destroy" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0xccbfa2b7, "wake_up_process" },
	{ 0xc58b3926, "kthread_create_on_node" },
	{ 0xc1514a3b, "free_irq" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0xdca0b809, "device_create" },
	{ 0xfcff42d, "__class_create" },
	{ 0x27900d89, "cdev_add" },
	{ 0x97823d2e, "cdev_init" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0xf9a482f9, "msleep" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xb3f7646e, "kthread_should_stop" },
	{ 0xf43e904a, "pv_ops" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x4fd3ff86, "kmem_cache_alloc_trace" },
	{ 0x1c03e593, "kmalloc_caches" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x37a0cba, "kfree" },
	{ 0x9d2ab8ac, "__tasklet_schedule" },
	{ 0xc5850110, "printk" },
	{ 0x4629334c, "__preempt_count" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "D35411B97E177CC742ED7CA");
